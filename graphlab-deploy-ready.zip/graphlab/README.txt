GraphLab - Desmos-style graphing calculator

Open index.html in Chrome, Safari or Firefox (internet needed to load math.js).
Features: 2D graphing, sliders, inequalities, polar, parametric, 3D surfaces, PNG export.
